Sample Instagram personal-data export (fictional 'Glow Studio' candle business)
for workshop practice. Structure matches Settings -> Your activity -> Download
your information. Upload this zip to Claude with the Instagram Dashboard skill installed.
